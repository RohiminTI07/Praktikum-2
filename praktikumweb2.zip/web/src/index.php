<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Form Nilai</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>
<body>
    <div class="container-fluid">
		<div class="row">
			<div class="col-md-12 bg-primary p-4">
			<h3 class="text-center text-white" >
				Form Nilai Mahasiswa
			</h3>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-5 mt-3">
				<form role="form">
					<form action="index.html" method="get" class="mt-3">
						<div class="form-group">
					 
							<label for="">
								Nama Lengkap
							</label>
							<input type="text" name="nama" value="" class="form-control">
						</div>
						<div class="form-group">
					 
							<label for="">
								NIM
							</label>
							<input type="number" name="nim" value="" class="form-control" >
						</div>
						<div class="form-group">
							<label for="">
								Mata kuliah
							</label>
                			<select class="form-select form-control" name="matkul" class="form-control">
								<option selected>Pilih Mata Kuliah</option>
								<option value="Web Programming">Web Programming</option>
								<option value="Basis data">Basis Data</option>
								<option value="Statiska">Statiska</option>
								<option value="PPKN">PPKN</option>
								<option value="UI/UX">UI/UX</option>
								<option value="B.Inggris">B.Inggris</option>
								<option value="B.Indonesia">B.Indonesia</option>
								<option value="Jaringan Komputer">Jaringan Komputer</option>
								<option value="Keterampilan komunikasi">Keterampilan Komunikasi</option>
								<option value="Pendidikan Agama">Pendidikan Agama</option>
								<option value="Matematika Komputer">Matematika Komputer</option>
								<option value="PTI">PTI</option>
							</select>
						</div>
						<div class="form-group">
					 
							<label for="">
								Nilai UTS
							</label>
							<input type="number" name="uts" value="" class="form-control">
						</div>
						<div class="form-group">
							<label for="">
								Nilai UAS
							</label>
							<input type="number" name="uas" value="" class="form-control">
						</div>
						<div class="form-group">
							<label for="">
								Nilai Tugas Praktikum
							</label>
							<input type="number" name="tugas" value="" class="form-control">
						</div>
						<button type="submit" value="Kirim" name="proses" class="btn btn-primary  btn-block">
							Kirim
						</button>
					</form>
				</form>	
			</div>
		</div>
	</div>

	
	<?php
	if(isset($_GET['proses'])) {
		
		$proses = $_GET['proses'];
		$nama = $_GET['nama'];
		$nim = $_GET['nim'];
		$matkul = $_GET['matkul'];
		$uts = $_GET['uts'];
		$uas = $_GET['uas'];
		$tugas = $_GET['tugas'];

		$total = $uts + $uas + $tugas;
		$hasil = $total/ 3;
		$presentasi = ($uts * 30 / 100) +($uas * 35 / 100 ) + ($tugas * 35 / 100 );
		
		if($presentasi < 55){
			$keterangan = "Tidak Lulus";
		}else {
			$keterangan = "Lulus";
		}
		
		if($hasil >= 85 && $hasil <= 100){
			$grade = "A";
			$predikat = "Sangat Memuaskan";
		}
		elseif($hasil >= 70 && $hasil < 85){
			$grade = "B";
			$predikat = "Memuaskan";
		}
		elseif($hasil >= 56 && $hasil < 70){
			$grade = "C";
			$predikat = "Cukup";
		}
		elseif($hasil >= 36 && $hasil < 56){
			$grade = "D";
			$predikat = "Kurang";
		}
		elseif($hasil >= 0 && $hasil < 36){
			$grade = "E";
			$predikat = "Sangat Kurang";
		}
		elseif($hasil < 0 && $hasil > 100){
			$grade = "I";
			$predikat = "Tidak ada";
		}
		
	}
		?>

<!-- <?php
        if (isset($_GET['nama']) 
        AND isset($_GET['nim'])
        AND isset($_GET['matkul'])
        AND isset($_GET['uts'])
        AND isset($_GET['uas'])
        AND isset($_GET['tugas']))
        {

        }
        else
        {
        echo "Maaf, anda harus mengakses halaman ini";
        }

    ?>
 -->
	<div class="col-3 mt-4">
			<div class="list-group">
				 <h5 class="card-header bg-primary text-white text-center" >Grade</h5>
				<div class="list-group-item">
					A : 85 - 100
				</div>
				<div class="list-group-item">
					B : 70 - 84
				</div>
				<div class="list-group-item">
					C : 56 - 69
				</div>
				<div class="list-group-item">
					D : 36 - 55
				</div>
				<div class="list-group-item">
					E : 0 - 35
				</div>
				<div class="list-group-item">
					I : Lebih Besar Dari 100 
				</div>
			</div>
		</div>

		<div class="col-3 mt-4">
			<div class="list-group">
				 <h5 class="card-header bg-primary text-white text-center" >Hasil</h5>
				<div class="list-group-item">
					Nama : <?=$nama?>
				</div>
				<div class="list-group-item">
					NIM : <?=$nim?>
				</div>
				<div class="list-group-item">
					Mata kuliah : <?=$matkul?>
				</div>
				<div class="list-group-item">
					Nilai UTS : <?=$uts?>
				</div>
				<div class="list-group-item">
					Nilai UAS : <?=$uas?>
				</div>
				<div class="list-group-item">
					Nilai Tugas Praktikum : <?=$tugas?>
				</div>
				<div class="list-group-item">
					Total Nilai : <?=$hasil?>
				</div>
				<div class="list-group-item">
					Grade : <?=$grade?>
				</div>
				<div class="list-group-item">
					Predikat : <?=$predikat?>
				</div>
				<div class="list-group-item">
					Presentase Nilai : <?=$presentasi . '%'?>
				</div>
				<div class="list-group-item">
					Keterangan : <?=$keterangan?>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
			</div>
		</div>
	</div>
</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>